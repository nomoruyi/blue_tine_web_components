package com.example.blue_tine_web_components

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
